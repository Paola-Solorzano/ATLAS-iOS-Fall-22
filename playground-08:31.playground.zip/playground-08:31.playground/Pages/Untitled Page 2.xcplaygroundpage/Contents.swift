//: [Previous](@previous)

import Foundation

var name: String?

func sayHi(name: String) {
    "Hi \(name)"
}

name = "Paola"

print("\(name)")
name

if let name = name {
    print("About to execute")
    sayHi(name: name)
}


let customName: String
if let name = name {
    customName = name
}
else {
    customName = "friend"
}

sayHi(name: customName)





//: [Next](@next)
