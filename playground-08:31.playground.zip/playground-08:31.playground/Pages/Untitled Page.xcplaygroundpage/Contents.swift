import UIKit

//struct Person {
//    var name: String
//}

typealias SpecialNumber = Int

typealias Coordinate = (x: Int, y: Int)
var coordinates: Coordinate = (0, 20)

var myNumber: SpecialNumber = 2

coordinates.0
coordinates.1

coordinates.x
coordinates.y

print (coordinates)

enum CardinalDirection: String {
    case north, east, south, west
    
    var description: String {
        rawValue
    }
    
    var axis: String {
        switch self {
        case .north, .south:
            return("vertical")
        case .east, .west:
            return("horizontal")
        }
    }
}

var direction = CardinalDirection.north
direction.axis
direction.rawValue

struct Person {
    var firstName: String
    var lastName: String
}

let me = Person(firstName: "Paola", lastName: "Solorzano Bravo")

class Human {
    var firstName: String
    var lastName: String
    
    init(name: String) {
        let components = name.components(separatedBy: " ")
        firstName = components.first ?? ""
        lastName = components.last ?? ""
    }
}

let human = Human(name: "Paola SolorzanoBravo")
human.firstName
human.lastName

human.firstName = "Jonathan"
human.firstName

struct Coordinates {
    let x: Int
    let y: Int
    
    var description: String {
        "\(x),\(y)"
    }
    
    static var zero: Coordinates {
        return Coordinates(x: 0, y: 20)
    }
}

let start = Coordinates(x: 0, y: 20)

start.description
Coordinates.zero


//var list: Array<Int> = [0,2,3,4,8,93]
//var list: [Int] = [0,2,3,4,8,93] //shorthand for the line above
var list = [Int]()

//for (index, _) in list.enumerated() {
//    print("On item /(index)")
//}
//list.append(2)
//list.append(3)
//list.append(4)
//list.append(8)
//list.append(93)


var dictionary = [Int:String]() //shorthand
//var dictionary = Dictionary<Int,String>() //longhand

dictionary[3] = "Three"
dictionary

dictionary[3]
dictionary[4]

//func doStuff() -> Void {} //same thing, if function doesn't do anything, it return Void
func math(_ number: Int, _ other: Int = 5, another: Int = 1) -> Int { //use -> when you only have 1 line in the {} //_ means you don't need 'number:' below
//    print("Hi")
//    return 3+4 //use return for more than 1 line
    return number + other + another
}

func math(_ number: Float, _ other: Float = 5) -> Float { //use -> when you only have 1 line in the {} //_
    print("hi")
    return number + other
}

//math(number: 4)
//math(4)
math(4)
math(4, 10)
//math(4, 10, another: 3)
math(4.0, 10)
